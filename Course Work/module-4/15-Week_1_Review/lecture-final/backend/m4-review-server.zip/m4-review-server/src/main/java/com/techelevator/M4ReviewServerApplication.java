package com.techelevator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M4ReviewServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(M4ReviewServerApplication.class, args);
	}

}
